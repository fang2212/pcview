#!/bin/bash

python3 run_pcview.py --func debug
