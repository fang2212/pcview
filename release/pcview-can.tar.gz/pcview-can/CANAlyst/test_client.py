#!/usr/bin/python3.6
import time
from os import path
from sys import path as sys_path

thisfiledir = path.dirname(path.abspath(__file__))
rootdir = path.dirname(thisfiledir)
#if rootdir not in sys_path:
#    sys_path.append(rootdir)
from socketCAN_Basic import CANBasic


myCAN = CANBasic(can_name='can0')

with open('can_txt_aeb_testuse', 'r') as f:
    cnt = 0
    for line in f:
        try:
            if line:
                linelist = line.split('  ')
                can_id = int(linelist[2], 16)
                datalist = linelist[-1].split(' ')
                int_data_list = []
                for item in datalist:
                    int_data_list.append(int(item, 16))
                myCAN.send(can_id, int_data_list)
                cnt += 1
                print(cnt, can_id, datalist)
                time.sleep(0.1)
            else:
                break
        except Exception as err:
            print(err)
    # cansend can0 18fe5be8#d38ffc00ff00ff00
    #frdata = ['0x18FE5BE8', 'D3', '8F', 'FC', '00', 'FF', '00', 'FF', '00']
    #print(frdata)