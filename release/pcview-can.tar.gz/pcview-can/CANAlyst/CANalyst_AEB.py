import json

from socketCAN_Basic import CANBasic


class CANX(CANBasic):
    """CAN报文分析
    Arguments:
        object {[type]} -- [description]
    Keyword Arguments:
        can_name {str} -- CAN的名字, 正式连接设备使用时不能为None，否则不能创建CAN实例
        bitrate {int} -- 比特率 (default: {500000})
    """

    def __init__(self, can_name=None, bitrate=500000):
        super().__init__(can_name, bitrate)

    def input_jsonfile_to_dict(self, filepath):
        with open(filepath, 'r') as f:
            can_input_rule_dict = json.loads(f.read())
            self.speed_rule_dict = can_input_rule_dict['speed']
            self.left_turn_rule_dict = can_input_rule_dict['left_turn'] 
            self.right_turn_rule_dict = can_input_rule_dict['right_turn']

    def __dec_to_hexlist(self, val, target_dict):
        val = int((float(val) - target_dict['offset']) / target_dict['factor'])
        start_bit = target_dict['start_bit']
        size = target_dict['size']
        if val <= 2**size - 1:
            bin_val_str = bin(val)[2:].zfill(size)
            full_bin_val_str = ''
            #63...0bit
            #高位段
            for _ in range(64-start_bit-size):
                full_bin_val_str += '0'
            #填充数据段
            full_bin_val_str += bin_val_str
            #低位段
            for _ in range(start_bit):
                full_bin_val_str += '0'
            #print(full_bin_val_str)
            frdata = [None]*8
            #Intel
            if target_dict['byte_order']==0:
                for i in range(0, 8, 2):
                    j=i+1
                    frdata[7-i] = hex(int(full_bin_val_str[8*i:8*(i+1)], 2))
                    frdata[7-j] = hex(int(full_bin_val_str[8*j:8*(j+1)], 2))
            #Motorala
            else:
                for i in range(0, 8, 2):
                    j=i+1
                    frdata[7-j] = hex(int(full_bin_val_str[8*i:8*(i+1)], 2))
                    frdata[7-i] = hex(int(full_bin_val_str[8*j:8*(j+1)], 2))
            
            return frdata
        else:
            return 'error@input val overflow'

    def chg_msg_to_frame(self, key, val):
        can_id = None
        frdata = None
        if key == 'speed':
            frdata = self.__dec_to_hexlist(val, self.speed_rule_dict)
            can_id = self.speed_rule_dict['can_id']
        elif key == 'left-lamp':
            frdata = self.__dec_to_hexlist(val, self.left_turn_rule_dict)
            can_id = self.left_turn_rule_dict['can_id']
        elif key == 'right-lamp':
            frdata = self.__dec_to_hexlist(val, self.right_turn_rule_dict)
            can_id = self.right_turn_rule_dict['can_id']
        extend_id = True
        if len(can_id) <= 5:
            extend_id = False
        return can_id, frdata, extend_id

    def send_frame(self, can_id, frdata, extend_id):
        """发送用的frdata不包含帧ID，只包含8个数据"""
        if 'error@' not in frdata:
            try:
                self.send(can_id, frdata, extended_id=extend_id)
            except Exception as err:
                return can_id + ' ' + str(frdata) + ' error@' + str(err)
        return can_id + '@' + str(frdata)

    def output_jsonfile_to_dict(self, filepath):
        with open(filepath, 'r') as f:
            can_output_rule_dict = json.loads(f.read())
            self.can_output_vehicle_rule_dict = can_output_rule_dict['vehicle']
            self.vehicle_a1_can_id = self.can_output_vehicle_rule_dict['vehicle_a1']['can_id']
            self.vehicle_a2_can_id = self.can_output_vehicle_rule_dict['vehicle_a2']['can_id']

    def vehicle_a1_fcw(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a1']['fcw'], 
            self.vehicle_a1_can_id)
        return val

    def vehicle_a1_id(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a1']['fcw'], 
            self.vehicle_a1_can_id)
        return val

    def vehicle_a1_type(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a1']['type'], 
            self.vehicle_a1_can_id)
        return val

    def vehicle_a1_pos_x(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a1']['pos_x'], 
            self.vehicle_a1_can_id)
        return val
    
    def vehicle_a1_pos_y(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a1']['pos_y'], 
            self.vehicle_a1_can_id)
        return val

    def vehicle_a2_attc(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a2']['attc'], 
            self.vehicle_a2_can_id)
        return val

    def vehicle_a2_vel_x(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a2']['vel_x'], 
            self.vehicle_a2_can_id)
        return val

    def vehicle_a2_acce_x(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a2']['acce_x'], 
            self.vehicle_a2_can_id)
        return val

    def vehicle_a2_width(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a2']['width'], 
            self.vehicle_a2_can_id)
        return val

    def vehicle_a2_confidence(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_vehicle_rule_dict['vehicle_a2']['width'], 
            self.vehicle_a2_can_id)
        return val

    def __alyst_allmsg(self, frdata):
        res = {'data_frame': frdata}
        res['vehicle_a1_fcw'] = self.vehicle_a1_fcw(frdata)
        res['vehicle_a1_id'] = self.vehicle_a1_id(frdata)
        res['vehicle_a1_type'] = self.vehicle_a1_type(frdata)
        res['vehicle_a1_pos_x'] = self.vehicle_a1_pos_x(frdata)
        res['vehicle_a1_pos_y'] = self.vehicle_a1_pos_y(frdata)

        res['vehicle_a2_attc'] = self.vehicle_a2_attc(frdata)
        res['vehicle_a2_vel_x'] = self.vehicle_a2_vel_x(frdata)
        res['vehicle_a2_acce_x'] = self.vehicle_a2_acce_x(frdata)
        res['vehicle_a2_width'] = self.vehicle_a2_width(frdata)
        res['vehicle_a2_confidence'] = self.vehicle_a2_confidence(frdata)
        return res

    def alyst_allmsg(self, timeout=None):
        """从设备中读取一帧CAN消息进行分析
        """
        frdata = self.recv(timeout)
        return self.__alyst_allmsg(frdata)





