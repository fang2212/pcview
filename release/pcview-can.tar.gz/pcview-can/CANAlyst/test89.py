import time

from libflow_handler import LibflowHandler

def recv_callback(msghandler, data):
    print("recv :", data)
    msghandler.send(1234, topic="can.ouput")

def run_test():
    # send_topic 可选参数，默认的发送主题
    msghandler = LibflowHandler(uri='ws://localhost:8000', send_topic="can.data")
    # 设置收到消息的处理函数
    msghandler.subscribe(scribe_topic="can.input", recv_callback=recv_callback)

    # 测试发送数字
    msghandler.send(12345678, topic="can.data")

    #测试发送字符串
    msghandler.send("hello world")

    # 测试发送json数据
    data = [1234, {"name":"minieye", "psw":"12345"}]
    msghandler.send(data)

    # 连续发送
    while True:
        msghandler.send("hello world")
        time.sleep(5)

if __name__ == "__main__":
    run_test()
