'''
print('hello')
print(bin(int('01\n', 16)))
print(bytes([0x00, 0x01]))
print(bin(11), bin(11).zfill(4))


print(2**16)

val = (float(70) - 0) / 0.00792
print(val)
val = int(val)
print(val)
size = 1
start_bit = 50
val = 1

if val <= 2**size- 1:
    bin_val_str = bin(val)[2:].zfill(size)
    full_bin_val_str = ''
    for _ in range(64-start_bit-size):
        full_bin_val_str += '0'
    full_bin_val_str += bin_val_str
    for _ in range(start_bit):
        full_bin_val_str += '0'
    print(full_bin_val_str)
    frdata = [None]*8
    for i in range(8):
        frdata[7-i] = hex(int(full_bin_val_str[8*i:8*(i+1)], 2))
    print(frdata)

print(bin(8)[2:].zfill(8)[0:2])

print(int(b'1000'))
'''
for i in range(0, 8, 2):
    print(i)
    print(i+1)

a = [0, 1]
b = a[2-1:2-0]
b.append(2)
print(b)