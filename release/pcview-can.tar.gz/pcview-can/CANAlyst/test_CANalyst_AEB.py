#!/usr/bin/python3.6
import asyncio
import random
import time
from os import path, system
from sys import path as sys_path
#from multiprocessing import Process, Queue
#import msgpack
#import websockets

thisfiledir = path.dirname(path.abspath(__file__))
rootdir = path.dirname(thisfiledir)
#if rootdir not in sys_path:
#    sys_path.append(rootdir)
from CANalyst_AEB import CANX

system('sudo ifconfig can0 down')
system('sudo ip link set can0 type can bitrate 500000')
print('----')
system('sudo ifconfig can0 up')
jsonfiledir = path.join(rootdir, 'json')
can_rule_json = path.join(thisfiledir, path.join(jsonfiledir, 'can_aeb.json'))

myCAN = CANX(can_name='can0')
myCAN.output_jsonfile_to_dict(can_rule_json)

'''
async def hello(uri):
    async with websockets.connect(uri) as websocket:
        cnt = 0
        while True:
            cnt += 1
            print('从CAN设备中读取CAN帧进行解析', cnt)
            data = myCAN.alyst_allmsg(timeout=3600)
            print(data)
            data = {"type":'123', "data":data}
            data = msgpack.packb(data)
            msg = {
                'source': 'client123',
                'topic': 'hello.message',
                'data': data
            }
            data = msgpack.packb(msg)
            await websocket.send(data)
            print("send: ", msg)

            time.sleep(1)


asyncio.get_event_loop().run_until_complete(
    hello('ws://localhost:8000'))
print('hello')
'''
cnt = 0
while True:
    cnt += 1
    print('从CAN设备中读取CAN帧进行解析', cnt)
    res = myCAN.alyst_allmsg(timeout=3600)
    print(res)

