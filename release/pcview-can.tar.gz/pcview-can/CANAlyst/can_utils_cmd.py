#!/usr/bin/python3.6
import os

#os.system('sudo ifconfig vcan0 down')
#os.system('sudo ip link set vcan0 type vcan bitrate 500000')
#os.system('sudo ifconfig vcan0 up')

os.system('sudo ifconfig can0 down')
os.system('sudo ip link set can0 type can bitrate 500000')
print('----')
os.system('sudo ifconfig can0 up')
