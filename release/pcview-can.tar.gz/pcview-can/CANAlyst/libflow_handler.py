'''
requirment:
    python3 -m pip install websocket-client
    python3 -m pip install msgpack
'''


from threading import Thread
from queue import Queue
import json

from websocket import WebSocket
import msgpack

class LibflowHandler():
    '''
    libflow 消息发送及接收处理
    '''
    def __init__(self, uri='ws://localhost:8000', send_topic=None):
        self.uri = uri
        self.send_topic = send_topic
        self.scribe_topic = None
        self.recv_callback = None
        self.init_socket()

    def init_socket(self):
        # queue里面的是json格式的msg, 但data是序列化的
        self.send_queue = Queue()
        self.recv_queue = Queue()

        self.ws = WebSocket()
        self.ws.connect(self.uri)

        self.send_thread = Thread(target=self.auto_send, daemon=True)

        self.send_thread.start()


    def subscribe(self, scribe_topic, recv_callback=None):
        self.scribe_topic = scribe_topic
        self.recv_callback = recv_callback

        self.recv_thread = Thread(target=self.auto_recv, daemon=True)
        self.recv_thread.start()


    def send(self, data, topic=None, pack_data=True):
        topic = topic or self.send_topic
        # 序列化data, data是订阅的topic时不能序列化, 这是libflow的bug
        if pack_data:
            data = msgpack.packb(data)
        msg = {
            'source': 'client1234',
            'topic': topic,
            'data': data,
        }
        self.send_queue.put(msg)

    def recv(self):
        if not self.scribe_topic:
            return None
        #当设置了callback后，不能再获取消息
        elif callable(self.recv_callback):
            return None
        else:
            data = self.recv_queue.get()
            return data

    def pack_msg(self, msg):
        return msgpack.packb(msg)

    def unpack_msg(self, msg):
        msg = msgpack.unpackb(msg, raw=False)
        data = msg.get('data')
        data = msgpack.unpackb(data, raw=False)
        return data

    def auto_send(self):
        while True:
            msg = self.send_queue.get()
            msg = self.pack_msg(msg)
            self.ws.send(msg, opcode=0x02)

    def auto_recv(self):
        if self.scribe_topic is not None:
            self.send(data=self.scribe_topic, topic="subscribe", pack_data=False)
            print("subscribe： ", self.scribe_topic)
            while True:
                msg = self.ws.recv()
                data = self.unpack_msg(msg)
                # 如果设置了callback，用callback来处理消息，否则推到queue里面等待读取
                if callable(self.recv_callback):
                    self.recv_callback(data)
                else:
                    self.recv_queue.put(data)

    def __del__(self):
        self.ws.close()





