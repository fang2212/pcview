import time
from os import path, system
from sys import path as sys_path

thisfiledir = path.dirname(path.abspath(__file__))
rootdir = thisfiledir
if rootdir not in sys_path:
    sys_path.append(rootdir)
jsonfiledir = path.join(rootdir, 'json')
from CANalyst_X1S import CANX

class TRunner(object):
    def __init__(self, testType, can_bitrate, can_queue=None):
        self.testType = testType
        self.can_queue = can_queue
        # CAN
        '''
        if testType == 'AEB':
            from CANalyst_AEB import CANX
            self.myCAN = CANX('can0', int(can_bitrate))
            can_input_rule_json = path.join(
                thisfiledir, path.join(jsonfiledir, 'can_input.json'))
            can_output_rule_json = path.join(
                thisfiledir, path.join(jsonfiledir, 'can_aeb.json'))
            self.myCAN.input_jsonfile_to_dict(can_input_rule_json)
            self.myCAN.output_jsonfile_to_dict(can_output_rule_json)
        elif testType == 'X1S':
        '''
        self.myCAN = CANX('can0', int(can_bitrate))
        can_input_rule_json = path.join(
            thisfiledir, path.join(jsonfiledir, 'can_input.json'))
        can_output_rule_json = path.join(
            thisfiledir, path.join(jsonfiledir, 'can_output_Xsrl.json'))
        self.myCAN.input_jsonfile_to_dict(can_input_rule_json)
        self.myCAN.output_jsonfile_to_dict(can_output_rule_json)

    def run_test(self):
        # 连续发送
        cnt = 0
        while True:
            data = self.myCAN.alyst_allmsg(timeout=3600)
            #print(data)
            if self.can_queue and data:
                self.can_queue.put(data)
            cnt += 1
            #print('CAN msg num', cnt)
            time.sleep(0)


def main():
    system('sudo ifconfig can0 down')
    system('sudo ip link set can0 type can bitrate 500000')
    print('----')
    system('sudo ifconfig can0 up')
    debug = True
    if debug:
        testType = 'X1S'
        can_bitrate = 500000
    else:
        testType = input('测试类型:')
        can_bitrate = input('CAN波特率:')
    x = TRunner(testType, can_bitrate)
    x.run_test()


if __name__ == "__main__":
    main()
