
from can.interfaces.socketcan.socketcan_native import SocketcanNative_Bus

from can.message import Message


class CANBasic(object):
    """CAN报文读取发送
    Arguments:
        object {[type]} -- [description]
    Keyword Arguments:
        can_name {str} -- CAN的名字, 正式连接设备使用时不能为None，否则不能创建CAN实例
        bitrate {int} -- 比特率 (default: {500000})
    """

    def __init__(self, can_name=None, bitrate=500000):
        if can_name:
            self.bus = SocketcanNative_Bus(channel=can_name, bitrate=bitrate)

    def send(self, can_id, data, is_remote_frame=False, extended_id=True, timeout=None):
        """发送帧
        Arguments:
            can_id {16进制数字} -- 如 0x01
            data {list or tuple} -- 8个16进制数
        Keyword Arguments:
            timeout {int or float} -- 超时时间(s) (default: {None})
        """
        msg = Message(arbitration_id=can_id, data=bytes(data),
                      is_remote_frame=is_remote_frame, extended_id=extended_id)
        self.bus.send(msg)
        print("Sender sent a message.", msg)

    def recv(self, timeout=None):
        """接收帧
        Keyword Arguments:
            timeout {int or float} -- 超时时间(s) (default: {None})
        Returns:
            {list} -- 帧ID 加上数据字节数，总共最大9个元素
        """
        try:
            #print("Receiver is waiting for a message...")
            recvmsg = self.bus.recv(timeout)
            frdata = [hex(recvmsg.arbitration_id)]
            for item in recvmsg.data:
                frdata.append(hex(item)[2:].zfill(2))
            #print("Receiver got: ", recvmsg)
            return frdata
        except Exception as err:
            return 'error@' + str(err)

    def output_core_alyst(self, frdata, target, can_id=None):
        """[summary]
        Arguments:
            frdata {list} -- 读取回来的帧ID+帧数据
            target {dict} -- 要解析的目标(内容通过字典存储)
            can_id {hex} -- 帧ID
        Returns:
            [type] -- 返回解析完的数字，字符串
        """
        try:
            if can_id is None:
                can_id = target['can_id']
            if int(frdata[0], 16) == int(can_id, 16):
                start_byte = target['start_byte']
                start_bit = target['start_bit']
                size = target['size']
                int_val = int(frdata[start_byte + 1], 16)
                bin_val = bin(int_val)[2:].zfill(8)[8-size-start_bit:8-start_bit]
                int_val = int(bin_val, 2)
                target_val = target['offset'] + int_val * target['factor']
                if target_val >= target['min'] and target_val <= target['max']:
                    target_val = str(target_val) + ' 合格'
                else:
                    target_val = str(target_val) + ' 不合格'
                return target_val
            else:
                return None
        except Exception as err:
            return 'error@' + str(err)

    def frdata_to_bin(self, frdata):
        """将8个字节转换为63~0个bit
        Arguments:
            frdata {list} -- 8个字节的数据帧
        """
        new_frdata = frdata
        if len(new_frdata) <= 8:
            for _ in range(8-len(new_frdata)):
                new_frdata.append(0x00)
        bin_val = ''
        for i in range(0, 8, 2):
            j = i+1
            bin_val += bin(new_frdata[7-i])[2:].zfill(8)
            bin_val += bin(new_frdata[7-j])[2:].zfill(8)
        return bin_val
        

                
            
