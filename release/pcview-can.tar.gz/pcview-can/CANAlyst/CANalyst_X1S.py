
import json

from socketCAN_Basic import CANBasic


class CANX(CANBasic):
    """CAN报文分析
    Arguments:
        object {[type]} -- [description]
    Keyword Arguments:
        can_name {str} -- CAN的名字, 正式连接设备使用时不能为None，否则不能创建CAN实例
        bitrate {int} -- 比特率 (default: {500000})
    """

    def __init__(self, can_name=None, bitrate=500000):
        super().__init__(can_name, bitrate)

    def output_jsonfile_to_dict(self, filepath):
        with open(filepath, 'r') as f:
            self.can_output_rule_dict = json.loads(f.read())

    def input_jsonfile_to_dict(self, filepath):
        with open(filepath, 'r') as f:
            can_input_rule_dict = json.loads(f.read())
            self.speed_rule_dict = can_input_rule_dict['speed']
            self.left_turn_rule_dict = can_input_rule_dict['left_turn'] 
            self.right_turn_rule_dict = can_input_rule_dict['right_turn']

    def vehicle_headway(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['vehicle']['headway'])
        return val

    def vehicle_ttc(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['vehicle']['ttc'])
        return val

    def vehicle_fcw(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['vehicle']['fcw'])
        return val

    def vehicle_speeding(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['vehicle']['speeding'])
        return val

    def ui_HMW_showdist(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['ui']['HMW_showdist'])
        return val

    def ui_beep(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['ui']['beep'])
        return val

    def lane_enable(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['lane']['lane_enable'])
        return val

    def lane_left_lane(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['lane']['left_lane'])
        return val

    def lane_right_lane(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['lane']['right_lane'])
        return val

    def lane_left_change(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['lane']['left_change'])
        return val

    def lane_right_change(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['lane']['right_change'])
        return val

    def ped_dangerous(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['ped']['ped_dangerous'])
        return val

    def ped_collision(self, frdata):
        val = self.output_core_alyst(
            frdata, self.can_output_rule_dict['ped']['ped_collision'])
        return val

    def __alyst_allmsg(self, frdata):
        res = {'data_frame': frdata}
        res['vehicle_headway'] = self.vehicle_headway(frdata)
        res['vehicle_ttc'] = self.vehicle_ttc(frdata)
        res['vehicle_fcw'] = self.vehicle_fcw(frdata)
        res['vehicle_speeding'] = self.vehicle_speeding(frdata)
        res['ui_HMW_showdist'] = self.ui_HMW_showdist(frdata)
        res['ui_beep'] = self.ui_beep(frdata)
        res['lane_enable'] = self.lane_enable(frdata)
        res['lane_left_lane'] = self.lane_left_lane(frdata)
        res['lane_right_lane'] = self.lane_right_lane(frdata)
        res['lane_left_change'] = self.lane_left_change(frdata)
        res['lane_right_change'] = self.lane_right_change(frdata)
        res['ped_dangerous'] = self.ped_dangerous(frdata)
        res['ped_collision'] = self.ped_collision(frdata)
        return res

    def __alyst_bydcanmsg(self, frdata):
        """分析比亚迪的0x3169报文"""
        bin_val = frdata
        res = {'data_frame': frdata}

        j_val = bin_val[1] & (1<<4 | 1<<5)
        j_val = j_val>>4
        res['left_ldw'] = j_val

        j_val = bin_val[2] & (1<<3 | 1<<4 | 1<<5)
        j_val = j_val>>3
        res['lane_help_state'] = j_val

        j_val = bin_val[5] & (1<<2 | 1<<3)
        j_val = j_val>>2
        res['right_ldw'] = j_val

        j_val = bin_val[7] & (1<<0 | 1<<1)
        j_val = j_val>>0
        res['warning_type'] = j_val

        return res

    def alyst_allmsg(self, timeout=None):
        """从设备中读取一帧CAN消息进行分析
        """
        frdata = self.recv(timeout)
        #print(frdata)
        for index in range(0, len(frdata)):
            frdata[index] = int(frdata[index], 16)
            #print(frdata[index])
            #print(frdata)
        #print(frdata)
        if frdata[0] == 0x316:
            res = self.__alyst_bydcanmsg(frdata)
            print(frdata)
        else:
            return {}
            res = self.__alyst_allmsg(frdata)

        return res
        new_res = {}
        for key, val in res.items():
            if val:
                new_res[key] = val
        return new_res

    def alyst_allmsg_from_file(self, filepath):
        """从文本文件逐行读取CAN消息进行分析
        """
        res = []
        with open(filepath, 'r') as f:
            for line in f:
                if line:
                    linelist = line.split('  ')
                    frdata = [linelist[2]]
                    datalist = linelist[-1].split(' ')
                    for item in datalist:
                        frdata.append(item)
                    res.append(self.__alyst_allmsg(frdata))
                else:
                    break
        return res
